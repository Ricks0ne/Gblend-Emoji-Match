import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/ui/Navbar';
import Home from './pages/Home';
import SinglePlayer from './pages/SinglePlayer';
import Multiplayer from './pages/Multiplayer';
import { GameProvider } from './contexts/GameContext';
import { WalletProvider } from './contexts/WalletContext';

function App() {
  return (
    <WalletProvider>
      <GameProvider>
        <Router>
          <div className="min-h-screen bg-gray-100 flex flex-col">
            <Navbar />
            <main className="flex-1">
              <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/solo" element={<SinglePlayer />} />
                <Route path="/multiplayer" element={<Multiplayer />} />
                <Route path="/leaderboard" element={<Leaderboard />} />
                <Route path="/profile" element={<Profile />} />
              </Routes>
            </main>
            <Footer />
          </div>
        </Router>
      </GameProvider>
    </WalletProvider>
  );
}

// Placeholder components
const Leaderboard = () => (
  <div className="container mx-auto px-4 py-8">
    <h1 className="text-3xl font-bold mb-6">Leaderboard</h1>
    <div className="bg-white rounded-lg shadow-md p-6">
      <p className="text-gray-600 text-center">
        Leaderboard functionality will be implemented in the next version.
      </p>
    </div>
  </div>
);

const Profile = () => (
  <div className="container mx-auto px-4 py-8">
    <h1 className="text-3xl font-bold mb-6">Player Profile</h1>
    <div className="bg-white rounded-lg shadow-md p-6">
      <p className="text-gray-600 text-center">
        Profile functionality will be implemented in the next version.
      </p>
    </div>
  </div>
);

const Footer = () => (
  <footer className="bg-gray-800 text-white py-6">
    <div className="container mx-auto px-4">
      <div className="flex flex-col md:flex-row justify-between items-center">
        <div className="mb-4 md:mb-0">
          <h3 className="text-xl font-bold">Emoji Match Arena</h3>
          <p className="text-gray-400 text-sm">
            Match emojis, earn points, mint NFTs!
          </p>
        </div>
        <div className="text-center md:text-right text-sm text-gray-400">
          <p>&copy; 2025 Emoji Match Arena. All rights reserved.</p>
          <p>Built on Fluent Blockchain</p>
        </div>
      </div>
    </div>
  </footer>
);

export default App;
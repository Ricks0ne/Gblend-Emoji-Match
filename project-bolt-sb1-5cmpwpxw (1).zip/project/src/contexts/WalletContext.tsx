import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { WalletState } from '../types';
import { connectWallet, switchToFluentChain } from '../services/blockchain';
import { ethers } from 'ethers';

const defaultWalletState: WalletState = {
  isConnected: false,
  address: null,
  chainId: null,
  provider: null,
  isCorrectChain: false,
};

const WalletContext = createContext<{
  walletState: WalletState;
  connectToWallet: () => Promise<void>;
  disconnectWallet: () => void;
  switchToCorrectChain: () => Promise<boolean>;
}>({
  walletState: defaultWalletState,
  connectToWallet: async () => {},
  disconnectWallet: () => {},
  switchToCorrectChain: async () => false,
});

export const useWallet = () => useContext(WalletContext);

export const WalletProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [walletState, setWalletState] = useState<WalletState>(defaultWalletState);

  useEffect(() => {
    const checkAndConnectWallet = async () => {
      if (window.ethereum && window.ethereum.selectedAddress) {
        try {
          await connectToWallet();
        } catch (error) {
          console.error("Auto-connect failed:", error);
        }
      }
    };

    checkAndConnectWallet();
  }, []);

  const connectToWallet = async () => {
    if (!window.ethereum) {
      window.open('https://metamask.io/download/', '_blank');
      throw new Error("Please install MetaMask or another wallet to continue.");
    }

    try {
      const { address, chainId, provider } = await connectWallet();
      const isCorrectChain = chainId === 20993; // Fluent chain ID
      
      setWalletState({
        isConnected: true,
        address,
        chainId,
        provider,
        isCorrectChain,
      });
      
      if (!isCorrectChain) {
        await switchToCorrectChain();
      }
    } catch (error) {
      console.error("Failed to connect wallet:", error);
      throw error;
    }
  };

  const disconnectWallet = () => {
    setWalletState(defaultWalletState);
  };

  const switchToCorrectChain = async (): Promise<boolean> => {
    if (!window.ethereum || !walletState.provider) return false;
    
    try {
      const success = await switchToFluentChain(walletState.provider as ethers.BrowserProvider);
      
      if (success) {
        setWalletState(prevState => ({
          ...prevState,
          chainId: 20993,
          isCorrectChain: true,
        }));
      }
      
      return success;
    } catch (error) {
      console.error("Failed to switch to correct chain:", error);
      return false;
    }
  };

  useEffect(() => {
    if (window.ethereum) {
      const handleAccountsChanged = async (accounts: string[]) => {
        if (accounts.length === 0) {
          disconnectWallet();
        } else if (walletState.address !== accounts[0]) {
          await connectToWallet();
        }
      };

      const handleChainChanged = async () => {
        await connectToWallet();
      };

      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);

      return () => {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        window.ethereum.removeListener('chainChanged', handleChainChanged);
      };
    }
  }, [walletState.address]);

  return (
    <WalletContext.Provider value={{ walletState, connectToWallet, disconnectWallet, switchToCorrectChain }}>
      {children}
    </WalletContext.Provider>
  );
};
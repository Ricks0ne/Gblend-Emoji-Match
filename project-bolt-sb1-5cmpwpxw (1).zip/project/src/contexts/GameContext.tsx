import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { EmojiCategory, GameMode, GameState, GridPosition } from '../types';
import { 
  findMatches, 
  initializeGrid, 
  calculateMatchScore, 
  determineEmojiMastery,
  getRandomEmojiAny 
} from '../utils/emojiUtils';

// Initialize default category mastery
const defaultCategoryMastery: Record<EmojiCategory, number> = {
  [EmojiCategory.FRUITS]: 0,
  [EmojiCategory.SWEETS]: 0,
  [EmojiCategory.MEALS]: 0,
  [EmojiCategory.DRINKS]: 0,
  [EmojiCategory.SNACKS]: 0,
};

// Default game state
const initialGameState: GameState = {
  grid: [],
  score: 0,
  gameMode: 'solo',
  level: 1,
  time: 120, // Changed to 120 seconds (2 minutes)
  isGameOver: false,
  categoryMastery: { ...defaultCategoryMastery },
};

// Create game context
const GameContext = createContext<{
  gameState: GameState;
  initGame: (mode: GameMode) => void;
  swapEmojis: (pos1: GridPosition, pos2: GridPosition) => Promise<boolean>;
  processMatches: () => Promise<number>;
  resetGame: () => void;
}>({
  gameState: initialGameState,
  initGame: () => {},
  swapEmojis: async () => false,
  processMatches: async () => 0,
  resetGame: () => {},
});

// Hook to use the game context
export const useGame = () => useContext(GameContext);

// Game provider component
export const GameProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [gameState, setGameState] = useState<GameState>({ ...initialGameState });
  const [timer, setTimer] = useState<NodeJS.Timeout | null>(null);

  // Initialize game with mode
  const initGame = (mode: GameMode) => {
    // Grid size - reduced to 6x6 for easier gameplay
    const rows = 6;
    const cols = 6;
    
    // Initialize grid
    const newGrid = initializeGrid(rows, cols);
    
    // Set game state
    setGameState({
      grid: newGrid,
      score: 0,
      gameMode: mode,
      level: 1,
      time: 120, // 120 seconds (2 minutes)
      isGameOver: false,
      categoryMastery: { ...defaultCategoryMastery },
    });
    
    // Start timer
    startTimer();
  };

  // Start game timer
  const startTimer = () => {
    // Clear any existing timer
    if (timer) {
      clearInterval(timer);
    }
    
    // Set up new timer
    const newTimer = setInterval(() => {
      setGameState(prevState => {
        // Decrease time
        const newTime = prevState.time - 1;
        
        // Check if game over
        if (newTime <= 0) {
          clearInterval(newTimer);
          return { ...prevState, time: 0, isGameOver: true };
        }
        
        return { ...prevState, time: newTime };
      });
    }, 1000);
    
    setTimer(newTimer);
  };

  // Swap emojis in the grid
  const swapEmojis = async (pos1: GridPosition, pos2: GridPosition): Promise<boolean> => {
    // Check if positions are adjacent
    const isAdjacent = (
      (Math.abs(pos1.row - pos2.row) === 1 && pos1.col === pos2.col) ||
      (Math.abs(pos1.col - pos2.col) === 1 && pos1.row === pos2.row)
    );
    
    if (!isAdjacent) {
      return false;
    }
    
    // Create a new grid with the swap
    const newGrid = [...gameState.grid];
    const temp = newGrid[pos1.row][pos1.col];
    newGrid[pos1.row][pos1.col] = newGrid[pos2.row][pos2.col];
    newGrid[pos2.row][pos2.col] = temp;
    
    setGameState({ ...gameState, grid: newGrid });
    
    // Check if the swap creates a match
    const matches = findMatches(newGrid);
    
    if (matches.length === 0) {
      // No matches, swap back
      setTimeout(() => {
        const revertGrid = [...newGrid];
        revertGrid[pos1.row][pos1.col] = newGrid[pos2.row][pos2.col];
        revertGrid[pos2.row][pos2.col] = newGrid[pos1.row][pos1.col];
        
        setGameState({ ...gameState, grid: revertGrid });
      }, 500);
      
      return false;
    }
    
    // Process matches
    await processMatches();
    return true;
  };

  // Process matches in the grid
  const processMatches = async (): Promise<number> => {
    let currentGrid = [...gameState.grid];
    let totalScore = 0;
    let newCategoryMastery = { ...gameState.categoryMastery };
    
    // Find matches
    let matches = findMatches(currentGrid);
    
    while (matches.length > 0) {
      // Calculate score for matches
      matches.forEach(match => {
        const matchScore = calculateMatchScore(match.length);
        totalScore += matchScore;
        
        // Update category mastery
        const emoji = currentGrid[match[0].row][match[0].col];
        newCategoryMastery[emoji.category] += matchScore;
      });
      
      // Remove matched emojis (set to null temporarily)
      matches.flat().forEach(pos => {
        currentGrid[pos.row][pos.col] = null as any;
      });
      
      // Drop emojis down to fill gaps
      for (let col = 0; col < currentGrid[0].length; col++) {
        let emptyRow = -1;
        
        // Find and fill empty spaces from bottom to top
        for (let row = currentGrid.length - 1; row >= 0; row--) {
          if (!currentGrid[row][col]) {
            if (emptyRow === -1) emptyRow = row;
          } else if (emptyRow !== -1) {
            // Move emoji down
            currentGrid[emptyRow][col] = currentGrid[row][col];
            currentGrid[row][col] = null as any;
            emptyRow--;
          }
        }
      }
      
      // Fill in new emojis at the top
      for (let col = 0; col < currentGrid[0].length; col++) {
        for (let row = 0; row < currentGrid.length; row++) {
          if (!currentGrid[row][col]) {
            currentGrid[row][col] = getRandomEmojiAny();
          }
        }
      }
      
      // Update state with new grid and score
      setGameState(prevState => ({
        ...prevState,
        grid: [...currentGrid],
        score: prevState.score + totalScore,
        categoryMastery: newCategoryMastery,
      }));
      
      // Pause for animations
      await new Promise(resolve => setTimeout(resolve, 300));
      
      // Check for new matches
      matches = findMatches(currentGrid);
    }
    
    return totalScore;
  };

  // Reset game
  const resetGame = () => {
    // Clear timer
    if (timer) {
      clearInterval(timer);
      setTimer(null);
    }
    
    // Reset to initial state
    setGameState({ ...initialGameState });
  };

  // Clean up timer on unmount
  useEffect(() => {
    return () => {
      if (timer) {
        clearInterval(timer);
      }
    };
  }, [timer]);

  return (
    <GameContext.Provider value={{ gameState, initGame, swapEmojis, processMatches, resetGame }}>
      {children}
    </GameContext.Provider>
  );
};
// Game Types
export type EmojiType = {
  id: string;
  symbol: string;
  category: EmojiCategory;
};

export enum EmojiCategory {
  FRUITS = 'fruits',
  SWEETS = 'sweets',
  MEALS = 'meals',
  DRINKS = 'drinks',
  SNACKS = 'snacks',
}

export type GridPosition = {
  row: number;
  col: number;
};

export type GameMode = 'solo' | 'pvp';

export type GameState = {
  grid: EmojiType[][];
  score: number;
  gameMode: GameMode;
  level: number;
  time: number;
  isGameOver: boolean;
  categoryMastery: Record<EmojiCategory, number>;
};

// Player Types
export type Player = {
  id: string;
  name: string;
  walletAddress?: string;
  score: number;
  highScore: number;
  nfts: NFT[];
};

// NFT Types
export type NFT = {
  id: string;
  tokenId: string;
  score: number;
  gameMode: GameMode;
  seasonBadge: string;
  emojiMastery: EmojiCategory;
  timestamp: number;
  isSoulbound: boolean;
  imageUrl: string;
};

// Blockchain Types
export type WalletState = {
  isConnected: boolean;
  address: string | null;
  chainId: number | null;
  provider: any | null;
  isCorrectChain: boolean;
};

export type NFTMetadata = {
  name: string;
  description: string;
  image: string;
  attributes: {
    trait_type: string;
    value: string | number;
  }[];
};
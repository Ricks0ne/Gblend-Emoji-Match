import { EmojiCategory, GameMode, NFTMetadata } from '../types';
import { generateSeasonBadge, getMasteryTitle } from './emojiUtils';

// Generate NFT metadata based on game results
export const generateNFTMetadata = (
  score: number,
  gameMode: GameMode,
  emojiMastery: EmojiCategory,
  isSoulbound: boolean = false
): NFTMetadata => {
  const seasonBadge = generateSeasonBadge(score, gameMode);
  const masteryTitle = getMasteryTitle(emojiMastery);
  
  return {
    name: `Emoji Match Arena - ${seasonBadge}`,
    description: `This NFT represents achievement in Emoji Match Arena. The player scored ${score} points in ${gameMode === 'solo' ? 'Solo Mode' : 'PvP Mode'} and mastered the ${emojiMastery} emoji category, earning the title of ${masteryTitle}.${isSoulbound ? ' This is a Soulbound Token that cannot be transferred.' : ''}`,
    image: generateNFTImage(score, gameMode, emojiMastery),
    attributes: [
      {
        trait_type: "Score",
        value: score
      },
      {
        trait_type: "Game Mode",
        value: gameMode === 'solo' ? 'Solo Mode' : 'PvP Mode'
      },
      {
        trait_type: "Season Badge",
        value: seasonBadge
      },
      {
        trait_type: "Emoji Mastery",
        value: masteryTitle
      },
      {
        trait_type: "Soulbound",
        value: isSoulbound
      }
    ]
  };
};

// Generate a dynamic NFT image URL based on game results
// In a real app, this would generate an actual image
// For this example, we'll just return a placeholder URL
export const generateNFTImage = (
  score: number,
  gameMode: GameMode,
  emojiMastery: EmojiCategory
): string => {
  // In a real implementation, this would generate or reference an actual image
  // For our purposes, we'll use placeholder images
  const tier = score > 500 ? 'diamond' : score > 300 ? 'gold' : score > 100 ? 'silver' : 'bronze';
  
  // Using Pexels stock photos as placeholders
  const placeholderImages: Record<string, string> = {
    'diamond': 'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg',
    'gold': 'https://images.pexels.com/photos/1303081/pexels-photo-1303081.jpeg',
    'silver': 'https://images.pexels.com/photos/950241/pexels-photo-950241.jpeg',
    'bronze': 'https://images.pexels.com/photos/1040499/pexels-photo-1040499.jpeg'
  };
  
  return placeholderImages[tier];
};

// Format wallet address for display
export const formatWalletAddress = (address: string | null): string => {
  if (!address) return '';
  return `${address.substring(0, 6)}...${address.substring(address.length - 4)}`;
};
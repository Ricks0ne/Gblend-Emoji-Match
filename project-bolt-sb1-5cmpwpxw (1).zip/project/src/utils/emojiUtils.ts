import { EmojiCategory, EmojiType, GridPosition } from '../types';

// Define emoji sets by category (reduced number of emojis)
const emojiSets: Record<EmojiCategory, string[]> = {
  [EmojiCategory.FRUITS]: ['🍎', '🍌'],
  [EmojiCategory.SWEETS]: ['🍦', '🍪'],
  [EmojiCategory.MEALS]: ['🍕', '🍔'],
  [EmojiCategory.DRINKS]: ['☕', '🥤'],
  [EmojiCategory.SNACKS]: ['🥨', '🍿'],
};

// Generate a random emoji from a specific category
export const getRandomEmoji = (category: EmojiCategory): EmojiType => {
  const emojis = emojiSets[category];
  const randomIndex = Math.floor(Math.random() * emojis.length);
  return {
    id: `${category}-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
    symbol: emojis[randomIndex],
    category,
  };
};

// Generate a random emoji from any category
export const getRandomEmojiAny = (): EmojiType => {
  const categories = Object.values(EmojiCategory);
  const randomCategory = categories[Math.floor(Math.random() * categories.length)];
  return getRandomEmoji(randomCategory);
};

// Initialize a grid with random emojis
export const initializeGrid = (rows: number, cols: number): EmojiType[][] => {
  const grid: EmojiType[][] = [];
  
  for (let i = 0; i < rows; i++) {
    const row: EmojiType[] = [];
    for (let j = 0; j < cols; j++) {
      row.push(getRandomEmojiAny());
    }
    grid.push(row);
  }
  
  return grid;
};

// Check if emojis are the same (for matching)
export const areEmojisMatching = (emoji1: EmojiType, emoji2: EmojiType): boolean => {
  return emoji1.symbol === emoji2.symbol;
};

// Find all matches in the grid (3 or more consecutive same emojis)
export const findMatches = (grid: EmojiType[][]): GridPosition[][] => {
  const matches: GridPosition[][] = [];
  const rows = grid.length;
  const cols = grid[0].length;
  
  // Check horizontal matches
  for (let i = 0; i < rows; i++) {
    let currentMatch: GridPosition[] = [{ row: i, col: 0 }];
    
    for (let j = 1; j < cols; j++) {
      if (areEmojisMatching(grid[i][j-1], grid[i][j])) {
        currentMatch.push({ row: i, col: j });
      } else {
        if (currentMatch.length >= 3) {
          matches.push([...currentMatch]);
        }
        currentMatch = [{ row: i, col: j }];
      }
    }
    
    if (currentMatch.length >= 3) {
      matches.push([...currentMatch]);
    }
  }
  
  // Check vertical matches
  for (let j = 0; j < cols; j++) {
    let currentMatch: GridPosition[] = [{ row: 0, col: j }];
    
    for (let i = 1; i < rows; i++) {
      if (areEmojisMatching(grid[i-1][j], grid[i][j])) {
        currentMatch.push({ row: i, col: j });
      } else {
        if (currentMatch.length >= 3) {
          matches.push([...currentMatch]);
        }
        currentMatch = [{ row: i, col: j }];
      }
    }
    
    if (currentMatch.length >= 3) {
      matches.push([...currentMatch]);
    }
  }
  
  return matches;
};

// Calculate score based on match length (increased scores)
export const calculateMatchScore = (matchLength: number): number => {
  // Base score for 3 matches (increased)
  const baseScore = 20;
  
  // Bonus for matches longer than 3 (increased)
  const bonus = matchLength > 3 ? (matchLength - 3) * 10 : 0;
  
  return baseScore + bonus;
};

// Determine emoji mastery category based on gameplay
export const determineEmojiMastery = (categoryMastery: Record<EmojiCategory, number>): EmojiCategory => {
  let highestCategory = EmojiCategory.FRUITS;
  let highestScore = 0;
  
  Object.entries(categoryMastery).forEach(([category, score]) => {
    if (score > highestScore) {
      highestScore = score;
      highestCategory = category as EmojiCategory;
    }
  });
  
  return highestCategory;
};

// Generate a season badge based on score and time
export const generateSeasonBadge = (score: number, gameMode: string): string => {
  const season = "S1: Food Frenzy";
  
  if (score > 500) {
    return `${season} - Master Chef`;
  } else if (score > 300) {
    return `${season} - Sous Chef`;
  } else if (score > 100) {
    return `${season} - Line Cook`;
  } else {
    return `${season} - Kitchen Helper`;
  }
};

// Get mastery title based on category
export const getMasteryTitle = (category: EmojiCategory): string => {
  switch (category) {
    case EmojiCategory.FRUITS:
      return "Fruit Connoisseur";
    case EmojiCategory.SWEETS:
      return "Dessert Master";
    case EmojiCategory.MEALS:
      return "Gourmet Expert";
    case EmojiCategory.DRINKS:
      return "Beverage Specialist";
    case EmojiCategory.SNACKS:
      return "Snack Aficionado";
    default:
      return "Food Master";
  }
};
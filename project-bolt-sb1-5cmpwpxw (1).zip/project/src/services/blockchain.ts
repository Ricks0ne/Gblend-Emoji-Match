import { ethers } from 'ethers';
import { NFTMetadata } from '../types';

const NFT_ABI = [
  "function mint(address to, string memory tokenURI) public returns (uint256)",
  "function tokenURI(uint256 tokenId) public view returns (string memory)",
  "function balanceOf(address owner) public view returns (uint256)",
  "function ownerOf(uint256 tokenId) public view returns (address)"
];

const FLUENT_CONFIG = {
  chainId: 20993,
  chainName: 'Fluent',
  rpcUrl: 'https://rpc.dev.gblend.xyz',
  blockExplorerUrl: 'https://fluent-explorer.com',
  currencySymbol: 'FLT',
};

const NFT_CONTRACT_ADDRESS = "0x0000000000000000000000000000000000000000";

export const connectWallet = async (): Promise<{
  address: string;
  chainId: number;
  provider: ethers.BrowserProvider;
}> => {
  if (!window.ethereum) {
    throw new Error("Please install MetaMask or another Ethereum wallet to continue.");
  }

  try {
    const provider = new ethers.BrowserProvider(window.ethereum);
    
    // Request account access
    const accounts = await provider.send("eth_requestAccounts", []);
    
    if (accounts.length === 0) {
      throw new Error("No accounts found. Please connect your wallet.");
    }
    
    const address = accounts[0];
    const network = await provider.getNetwork();
    const chainId = Number(network.chainId);

    // Auto switch to Fluent chain if not on it
    if (chainId !== FLUENT_CONFIG.chainId) {
      await switchToFluentChain(provider);
    }
    
    return { address, chainId, provider };
  } catch (error) {
    console.error("Error connecting to wallet:", error);
    throw error;
  }
};

export const switchToFluentChain = async (provider: ethers.BrowserProvider): Promise<boolean> => {
  if (!window.ethereum) {
    throw new Error("Please install MetaMask or another Ethereum wallet to continue.");
  }

  try {
    await window.ethereum.request({
      method: "wallet_switchEthereumChain",
      params: [{ chainId: `0x${FLUENT_CONFIG.chainId.toString(16)}` }]
    });
    return true;
  } catch (switchError: any) {
    if (switchError.code === 4902) {
      try {
        await window.ethereum.request({
          method: "wallet_addEthereumChain",
          params: [
            {
              chainId: `0x${FLUENT_CONFIG.chainId.toString(16)}`,
              chainName: FLUENT_CONFIG.chainName,
              rpcUrls: [FLUENT_CONFIG.rpcUrl],
              blockExplorerUrls: [FLUENT_CONFIG.blockExplorerUrl],
              nativeCurrency: {
                name: FLUENT_CONFIG.chainName,
                symbol: FLUENT_CONFIG.currencySymbol,
                decimals: 18
              }
            }
          ]
        });
        return true;
      } catch (addError) {
        console.error("Error adding Fluent chain:", addError);
        return false;
      }
    }
    console.error("Error switching to Fluent chain:", switchError);
    return false;
  }
};

export const uploadMetadataToIPFS = async (metadata: NFTMetadata): Promise<string> => {
  // In a real implementation, this would upload to IPFS
  // For demo purposes, we'll simulate the upload
  console.log("Uploading metadata to IPFS:", metadata);
  await new Promise(resolve => setTimeout(resolve, 1000));
  return `ipfs://Qm${Math.random().toString(36).substring(2, 15)}`;
};

export const mintNFT = async (
  provider: ethers.BrowserProvider,
  address: string,
  metadata: NFTMetadata
): Promise<string> => {
  try {
    const tokenURI = await uploadMetadataToIPFS(metadata);
    const signer = await provider.getSigner();
    const nftContract = new ethers.Contract(NFT_CONTRACT_ADDRESS, NFT_ABI, signer);
    
    // Estimate gas for the transaction
    const gasEstimate = await nftContract.mint.estimateGas(address, tokenURI);
    
    // Add 20% buffer to gas estimate
    const gasLimit = Math.floor(gasEstimate.toString() * 1.2);
    
    // Send transaction with gas limit
    const tx = await nftContract.mint(address, tokenURI, {
      gasLimit: gasLimit
    });
    
    // Wait for transaction confirmation
    const receipt = await tx.wait();
    
    // Get token ID from event logs
    const mintEvent = receipt.logs.find(
      (log: any) => log.topics[0] === ethers.id("Transfer(address,address,uint256)")
    );
    
    const tokenId = mintEvent ? ethers.dataSlice(mintEvent.topics[3], 0) : `${Date.now()}`;
    return tokenId;
  } catch (error) {
    console.error("Error minting NFT:", error);
    throw error;
  }
};

export const mockMintNFT = async (
  address: string,
  metadata: NFTMetadata
): Promise<string> => {
  if (!window.ethereum) {
    throw new Error("Please install MetaMask or another Ethereum wallet to continue.");
  }

  try {
    // Simulate a transaction request
    const transactionRequest = {
      from: address,
      to: NFT_CONTRACT_ADDRESS,
      value: '0x0', // No ETH being sent
      data: '0x', // Contract interaction data would go here
    };

    // Request transaction signature
    await window.ethereum.request({
      method: 'eth_sendTransaction',
      params: [transactionRequest],
    });

    // Simulate transaction confirmation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const tokenId = `${Date.now()}-${Math.floor(Math.random() * 10000)}`;
    return tokenId;
  } catch (error) {
    console.error("Error in mock mint:", error);
    throw error;
  }
};
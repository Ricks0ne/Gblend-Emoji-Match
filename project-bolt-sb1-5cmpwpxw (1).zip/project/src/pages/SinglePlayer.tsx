import React, { useState, useEffect } from 'react';
import { useGame } from '../contexts/GameContext';
import EmojiGrid from '../components/game/EmojiGrid';
import ScoreBoard from '../components/game/ScoreBoard';
import NFTMint from '../components/wallet/NFTMint';
import WalletConnect from '../components/wallet/WalletConnect';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import { useWallet } from '../contexts/WalletContext';
import { NFT } from '../types';
import { RotateCcw, HelpCircle } from 'lucide-react';

const SinglePlayer: React.FC = () => {
  const { gameState, initGame, resetGame } = useGame();
  const { walletState } = useWallet();
  const [showMintModal, setShowMintModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [mintedNFTs, setMintedNFTs] = useState<NFT[]>([]);

  // Initialize solo game
  useEffect(() => {
    initGame('solo');
    
    return () => {
      resetGame();
    };
  }, []);

  // Handle game completion
  useEffect(() => {
    if (gameState.isGameOver && gameState.score > 0) {
      setShowMintModal(true);
    }
  }, [gameState.isGameOver, gameState.score]);

  // Handle mint completion
  const handleMintComplete = (nft: NFT) => {
    setMintedNFTs([...mintedNFTs, nft]);
  };

  // Start a new game
  const handleNewGame = () => {
    resetGame();
    initGame('solo');
    setShowMintModal(false);
  };

  // Show help modal
  const toggleHelpModal = () => {
    setShowHelpModal(!showHelpModal);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-3xl font-bold text-purple-800">Solo Game</h1>
        
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleHelpModal}
            leftIcon={<HelpCircle size={16} />}
          >
            How to Play
          </Button>
          
          <Button
            variant="primary"
            size="sm"
            onClick={handleNewGame}
            leftIcon={<RotateCcw size={16} />}
          >
            New Game
          </Button>
        </div>
      </div>
      
      {/* Game scoreoard */}
      <div className="mb-6">
        <ScoreBoard
          score={gameState.score}
          gameMode={gameState.gameMode}
          timeRemaining={gameState.time}
          level={gameState.level}
          categoryMastery={gameState.categoryMastery}
        />
      </div>
      
      {/* Game grid */}
      <div className="mb-8">
        <EmojiGrid />
      </div>
      
      {/* Game footer */}
      <div className="mt-8">
        {gameState.isGameOver ? (
          <div className="text-center">
            <h2 className="text-2xl font-bold mb-4">Game Over!</h2>
            <p className="text-lg mb-6">Your final score: <span className="font-bold text-purple-600">{gameState.score}</span></p>
            
            <div className="flex justify-center gap-4">
              <Button
                variant="primary"
                onClick={() => setShowMintModal(true)}
                disabled={!walletState.isConnected}
              >
                Mint NFT
              </Button>
              
              <Button
                variant="secondary"
                onClick={handleNewGame}
              >
                Play Again
              </Button>
            </div>
            
            {!walletState.isConnected && (
              <div className="mt-4 text-sm text-gray-600">
                Connect your wallet to mint an NFT for this achievement!
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white p-4 rounded-lg shadow-md">
            <h3 className="font-medium mb-2">Game Tips:</h3>
            <ul className="text-sm text-gray-600 list-disc list-inside">
              <li>Match 3 or more identical emojis in a row or column</li>
              <li>Longer matches earn more points</li>
              <li>Special combos can create powerful effects</li>
              <li>Try to master different emoji categories</li>
            </ul>
          </div>
        )}
      </div>
      
      {/* NFT Mint Modal */}
      <Modal
        isOpen={showMintModal}
        onClose={() => setShowMintModal(false)}
        title="Mint Your Achievement NFT"
      >
        {!walletState.isConnected ? (
          <WalletConnect onConnect={() => {}} />
        ) : (
          <NFTMint
            score={gameState.score}
            gameMode={gameState.gameMode}
            categoryMastery={gameState.categoryMastery}
            onMintComplete={handleMintComplete}
          />
        )}
      </Modal>
      
      {/* Help Modal */}
      <Modal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
        title="How to Play"
      >
        <div className="space-y-4">
          <div>
            <h3 className="font-bold mb-2">Game Rules:</h3>
            <ul className="list-disc list-inside text-gray-700">
              <li>Swap adjacent emojis to create matches of 3 or more identical emojis</li>
              <li>Matches can be horizontal or vertical</li>
              <li>Each match earns points based on the length of the match</li>
              <li>The game ends when the timer reaches zero</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold mb-2">Scoring:</h3>
            <ul className="list-disc list-inside text-gray-700">
              <li>3 emoji match: 10 points</li>
              <li>4 emoji match: 15 points</li>
              <li>5+ emoji match: 20+ points</li>
              <li>Each emoji category you master increases your score multiplier</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold mb-2">NFT Minting:</h3>
            <ul className="list-disc list-inside text-gray-700">
              <li>After each game, you can mint an NFT based on your score</li>
              <li>NFTs include your score, game mode, and emoji mastery</li>
              <li>Higher scores result in more valuable NFTs</li>
              <li>You can choose to make your NFT a Soulbound Token (non-transferable) or a tradable NFT</li>
            </ul>
          </div>
          
          <div className="pt-4">
            <Button variant="primary" onClick={toggleHelpModal} className="w-full">
              Got it!
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default SinglePlayer;
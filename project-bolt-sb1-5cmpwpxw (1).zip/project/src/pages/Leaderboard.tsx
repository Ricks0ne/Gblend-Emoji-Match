import React, { useState, useEffect } from 'react';
import { Trophy, Medal, Star, Clock, Award, User } from 'lucide-react';
import { useWallet } from '../contexts/WalletContext';
import Button from '../components/ui/Button';
import { format } from 'date-fns';

interface LeaderboardEntry {
  id: string;
  rank: number;
  playerName: string;
  score: number;
  gameMode: 'solo' | 'pvp';
  timestamp: number;
  walletAddress: string;
  seasonBadge: string;
  nftCount: number;
}

const Leaderboard: React.FC = () => {
  const { walletState } = useWallet();
  const [timeFilter, setTimeFilter] = useState<'all' | 'daily' | 'weekly' | 'monthly'>('all');
  const [modeFilter, setModeFilter] = useState<'all' | 'solo' | 'pvp'>('all');
  const [leaderboardData, setLeaderboardData] = useState<LeaderboardEntry[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [userRank, setUserRank] = useState<number | null>(null);

  useEffect(() => {
    const fetchLeaderboardData = async () => {
      setIsLoading(true);
      try {
        // In a real app, fetch from your backend/Supabase
        // Simulated data for demonstration
        const mockData: LeaderboardEntry[] = [
          {
            id: '1',
            rank: 1,
            playerName: "CryptoMaster",
            score: 2500,
            gameMode: "solo",
            timestamp: Date.now() - 3600000,
            walletAddress: "0x1234...5678",
            seasonBadge: "S1: Food Frenzy - Master Chef",
            nftCount: 12
          },
          {
            id: '2',
            rank: 2,
            playerName: "EmojiKing",
            score: 2350,
            gameMode: "pvp",
            timestamp: Date.now() - 7200000,
            walletAddress: "0x8765...4321",
            seasonBadge: "S1: Food Frenzy - Sous Chef",
            nftCount: 8
          },
          {
            id: '3',
            rank: 3,
            playerName: "BlockchainPro",
            score: 2200,
            gameMode: "solo",
            timestamp: Date.now() - 10800000,
            walletAddress: "0x9876...1234",
            seasonBadge: "S1: Food Frenzy - Line Cook",
            nftCount: 5
          }
        ];

        setLeaderboardData(mockData);

        // Set user's rank if wallet is connected
        if (walletState.isConnected) {
          setUserRank(42); // Simulated rank
        }
      } catch (error) {
        console.error('Error fetching leaderboard data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchLeaderboardData();
  }, [timeFilter, modeFilter, walletState.isConnected]);

  const getRankColor = (rank: number): string => {
    switch (rank) {
      case 1:
        return 'text-yellow-500'; // Gold
      case 2:
        return 'text-gray-400'; // Silver
      case 3:
        return 'text-amber-600'; // Bronze
      default:
        return 'text-gray-600';
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="text-yellow-500" size={20} />;
      case 2:
        return <Medal className="text-gray-400" size={20} />;
      case 3:
        return <Medal className="text-amber-600" size={20} />;
      default:
        return null;
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-purple-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Header */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex flex-col md:flex-row justify-between items-center">
          <div className="flex items-center mb-4 md:mb-0">
            <Trophy className="text-yellow-500 mr-4" size={32} />
            <div>
              <h1 className="text-2xl font-bold">Global Leaderboard</h1>
              <p className="text-gray-600">Season 1: Food Frenzy</p>
            </div>
          </div>

          {userRank && (
            <div className="bg-purple-50 px-6 py-3 rounded-lg">
              <div className="text-sm text-purple-600">Your Rank</div>
              <div className="text-2xl font-bold text-purple-800">#{userRank}</div>
            </div>
          )}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div className="flex flex-wrap gap-2">
            <div className="flex rounded-lg overflow-hidden border border-gray-200">
              <Button
                variant={timeFilter === 'all' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setTimeFilter('all')}
              >
                All Time
              </Button>
              <Button
                variant={timeFilter === 'daily' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setTimeFilter('daily')}
              >
                Daily
              </Button>
              <Button
                variant={timeFilter === 'weekly' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setTimeFilter('weekly')}
              >
                Weekly
              </Button>
              <Button
                variant={timeFilter === 'monthly' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setTimeFilter('monthly')}
              >
                Monthly
              </Button>
            </div>

            <div className="flex rounded-lg overflow-hidden border border-gray-200">
              <Button
                variant={modeFilter === 'all' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setModeFilter('all')}
              >
                All Modes
              </Button>
              <Button
                variant={modeFilter === 'solo' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setModeFilter('solo')}
              >
                Solo
              </Button>
              <Button
                variant={modeFilter === 'pvp' ? 'primary' : 'ghost'}
                size="sm"
                onClick={() => setModeFilter('pvp')}
              >
                PvP
              </Button>
            </div>
          </div>

          <div className="text-sm text-gray-500">
            Last updated: {format(new Date(), 'MMM d, yyyy HH:mm')}
          </div>
        </div>
      </div>

      {/* Leaderboard Table */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rank</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Player</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Score</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Mode</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Achievements</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Time</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {leaderboardData.map((entry) => (
                <tr key={entry.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      {getRankIcon(entry.rank)}
                      <span className={`font-bold ${getRankColor(entry.rank)} ${entry.rank <= 3 ? 'ml-2' : ''}`}>
                        #{entry.rank}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 flex items-center justify-center text-white">
                          <User size={20} />
                        </div>
                      </div>
                      <div className="ml-4">
                        <div className="text-sm font-medium text-gray-900">{entry.playerName}</div>
                        <div className="text-sm text-gray-500">{entry.walletAddress}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Star className="text-yellow-500 mr-2" size={16} />
                      <span className="text-lg font-semibold">{entry.score}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      entry.gameMode === 'solo'
                        ? 'bg-purple-100 text-purple-800'
                        : 'bg-pink-100 text-pink-800'
                    }`}>
                      {entry.gameMode.toUpperCase()}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center">
                      <Award className="text-purple-500 mr-2" size={16} />
                      <span className="text-sm text-gray-600">{entry.nftCount} NFTs</span>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">{entry.seasonBadge}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <div className="flex items-center">
                      <Clock className="mr-2" size={16} />
                      {format(entry.timestamp, 'MMM d, HH:mm')}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Connect Wallet CTA */}
      {!walletState.isConnected && (
        <div className="mt-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-lg p-8 text-center text-white">
          <h3 className="text-xl font-bold mb-4">Want to see your ranking?</h3>
          <p className="mb-6">Connect your wallet to track your progress and compete for the top spots!</p>
          <Button
            variant="accent"
            size="lg"
            onClick={() => walletState.connectToWallet()}
          >
            Connect Wallet
          </Button>
        </div>
      )}
    </div>
  );
};

export default Leaderboard;
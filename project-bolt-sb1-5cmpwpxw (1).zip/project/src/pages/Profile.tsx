import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useWallet } from '../contexts/WalletContext';
import { Trophy, Medal, Star, Clock, Award, User, Wallet } from 'lucide-react';
import Button from '../components/ui/Button';
import { NFT } from '../types';
import { formatWalletAddress } from '../utils/nftUtils';
import { format } from 'date-fns';

interface PlayerStats {
  totalGames: number;
  highScore: number;
  averageScore: number;
  winRate: number;
  totalPlayTime: number;
  favoriteMode: 'solo' | 'pvp';
}

const Profile: React.FC = () => {
  const navigate = useNavigate();
  const { walletState } = useWallet();
  const [playerStats, setPlayerStats] = useState<PlayerStats>({
    totalGames: 0,
    highScore: 0,
    averageScore: 0,
    winRate: 0,
    totalPlayTime: 0,
    favoriteMode: 'solo'
  });
  const [nfts, setNfts] = useState<NFT[]>([]);
  const [selectedNFT, setSelectedNFT] = useState<NFT | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!walletState.isConnected) {
      navigate('/');
      return;
    }

    const fetchPlayerData = async () => {
      setIsLoading(true);
      try {
        // In a real app, fetch from your backend/Supabase
        // Simulated data for demonstration
        setPlayerStats({
          totalGames: 42,
          highScore: 850,
          averageScore: 425,
          winRate: 65,
          totalPlayTime: 3600,
          favoriteMode: 'solo'
        });

        // Simulated NFT data
        const mockNFTs: NFT[] = [
          {
            id: '1',
            tokenId: '12345',
            score: 850,
            gameMode: 'solo',
            seasonBadge: 'S1: Food Frenzy - Master Chef',
            emojiMastery: 'fruits',
            timestamp: Date.now() - 86400000,
            isSoulbound: true,
            imageUrl: 'https://images.pexels.com/photos/1762851/pexels-photo-1762851.jpeg'
          },
          {
            id: '2',
            tokenId: '12346',
            score: 650,
            gameMode: 'pvp',
            seasonBadge: 'S1: Food Frenzy - Sous Chef',
            emojiMastery: 'sweets',
            timestamp: Date.now() - 172800000,
            isSoulbound: false,
            imageUrl: 'https://images.pexels.com/photos/1303081/pexels-photo-1303081.jpeg'
          }
        ];
        setNfts(mockNFTs);
      } catch (error) {
        console.error('Error fetching player data:', error);
      } finally {
        setIsLoading(false);
      }
    };

    fetchPlayerData();
  }, [walletState.isConnected, navigate]);

  const formatPlayTime = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-4 border-purple-500 border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Profile Header */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center mb-4 md:mb-0">
            <div className="w-20 h-20 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white">
              <User size={40} />
            </div>
            <div className="ml-4">
              <h1 className="text-2xl font-bold">Player Profile</h1>
              <div className="flex items-center text-gray-600">
                <Wallet size={16} className="mr-2" />
                <span>{formatWalletAddress(walletState.address)}</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="text-center">
              <div className="text-sm text-gray-500">Rank</div>
              <div className="font-bold text-xl text-purple-600">#42</div>
            </div>
            <div className="text-center">
              <div className="text-sm text-gray-500">NFTs</div>
              <div className="font-bold text-xl text-pink-600">{nfts.length}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">High Score</h3>
            <Trophy className="text-yellow-500" size={24} />
          </div>
          <div className="text-3xl font-bold text-purple-600">{playerStats.highScore}</div>
          <div className="text-sm text-gray-500 mt-2">Personal Best</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Win Rate</h3>
            <Medal className="text-blue-500" size={24} />
          </div>
          <div className="text-3xl font-bold text-purple-600">{playerStats.winRate}%</div>
          <div className="text-sm text-gray-500 mt-2">From {playerStats.totalGames} games</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Average Score</h3>
            <Star className="text-amber-500" size={24} />
          </div>
          <div className="text-3xl font-bold text-purple-600">{playerStats.averageScore}</div>
          <div className="text-sm text-gray-500 mt-2">Points per game</div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold">Play Time</h3>
            <Clock className="text-green-500" size={24} />
          </div>
          <div className="text-3xl font-bold text-purple-600">
            {formatPlayTime(playerStats.totalPlayTime)}
          </div>
          <div className="text-sm text-gray-500 mt-2">Total time played</div>
        </div>
      </div>

      {/* NFT Collection */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">NFT Collection</h2>
          <Award className="text-purple-500" size={24} />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {nfts.map((nft) => (
            <div
              key={nft.id}
              className="bg-gray-50 rounded-lg p-4 cursor-pointer transform transition-all hover:scale-105"
              onClick={() => setSelectedNFT(nft)}
            >
              <img
                src={nft.imageUrl}
                alt={nft.seasonBadge}
                className="w-full h-48 object-cover rounded-lg mb-4"
              />
              <div className="space-y-2">
                <div className="font-semibold text-lg">{nft.seasonBadge}</div>
                <div className="flex items-center text-gray-600">
                  <Trophy size={16} className="mr-2" />
                  <span>Score: {nft.score}</span>
                </div>
                <div className="flex items-center text-gray-600">
                  <Clock size={16} className="mr-2" />
                  <span>{format(nft.timestamp, 'MMM d, yyyy')}</span>
                </div>
                <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${
                  nft.isSoulbound
                    ? 'bg-purple-100 text-purple-800'
                    : 'bg-green-100 text-green-800'
                }`}>
                  {nft.isSoulbound ? 'Soulbound' : 'Transferable'}
                </div>
              </div>
            </div>
          ))}
        </div>

        {nfts.length === 0 && (
          <div className="text-center py-8">
            <div className="text-gray-400 mb-4">
              <Award size={48} className="mx-auto" />
            </div>
            <p className="text-gray-600">No NFTs minted yet. Play games to earn NFTs!</p>
            <Button
              variant="primary"
              className="mt-4"
              onClick={() => navigate('/solo')}
            >
              Play Solo Game
            </Button>
          </div>
        )}
      </div>

      {/* Game History */}
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Recent Games</h2>
          <Clock className="text-purple-500" size={24} />
        </div>

        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="text-left border-b">
                <th className="pb-3">Date</th>
                <th className="pb-3">Mode</th>
                <th className="pb-3">Score</th>
                <th className="pb-3">Result</th>
              </tr>
            </thead>
            <tbody>
              <tr className="border-b">
                <td className="py-3">{format(Date.now() - 3600000, 'MMM d, HH:mm')}</td>
                <td className="py-3">
                  <span className="px-2 py-1 rounded-full text-xs bg-purple-100 text-purple-800">
                    Solo
                  </span>
                </td>
                <td className="py-3 font-semibold">850</td>
                <td className="py-3">
                  <span className="text-green-600">Victory</span>
                </td>
              </tr>
              <tr className="border-b">
                <td className="py-3">{format(Date.now() - 7200000, 'MMM d, HH:mm')}</td>
                <td className="py-3">
                  <span className="px-2 py-1 rounded-full text-xs bg-pink-100 text-pink-800">
                    PvP
                  </span>
                </td>
                <td className="py-3 font-semibold">650</td>
                <td className="py-3">
                  <span className="text-red-600">Defeat</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default Profile;
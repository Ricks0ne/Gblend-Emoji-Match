import React from 'react';
import { Link } from 'react-router-dom';
import { Gamepad2, Users, User, Trophy } from 'lucide-react';
import Button from '../components/ui/Button';
import { useWallet } from '../contexts/WalletContext';

const Home: React.FC = () => {
  const { walletState, connectToWallet } = useWallet();

  return (
    <div className="min-h-screen bg-gradient-to-b from-purple-50 to-pink-50">
      {/* Hero Section */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center">
          <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-500 mb-6">
            Emoji Match Arena
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-10">
            Match emojis, earn points, and mint your achievements as unique NFTs on the Fluent blockchain!
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link to="/solo">
              <Button variant="primary" size="lg" leftIcon={<Gamepad2 size={20} />}>
                Play Solo
              </Button>
            </Link>
            <Link to="/multiplayer">
              <Button variant="secondary" size="lg" leftIcon={<Users size={20} />}>
                Play Multiplayer
              </Button>
            </Link>
            {!walletState.isConnected && (
              <Button variant="accent" size="lg" leftIcon={<User size={20} />} onClick={() => connectToWallet()}>
                Connect Wallet
              </Button>
            )}
          </div>
        </div>
        
        {/* Game Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          <div className="bg-white p-6 rounded-xl shadow-md transform transition-all hover:scale-105">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 rounded-full bg-purple-100 flex items-center justify-center">
                <Gamepad2 size={32} className="text-purple-600" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-center mb-2">Match & Earn</h3>
            <p className="text-gray-600 text-center">
              Match 3 or more emojis to score points. Longer matches earn bonus points!
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-md transform transition-all hover:scale-105">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 rounded-full bg-pink-100 flex items-center justify-center">
                <Trophy size={32} className="text-pink-600" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-center mb-2">Compete & Master</h3>
            <p className="text-gray-600 text-center">
              Play solo or against friends. Master different emoji categories to earn special badges.
            </p>
          </div>
          
          <div className="bg-white p-6 rounded-xl shadow-md transform transition-all hover:scale-105">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 rounded-full bg-yellow-100 flex items-center justify-center">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-yellow-600" width="32" height="32">
                  <path d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />
                </svg>
              </div>
            </div>
            <h3 className="text-xl font-bold text-center mb-2">Mint & Collect</h3>
            <p className="text-gray-600 text-center">
              Turn your achievements into unique NFTs on the Fluent blockchain. Build your collection!
            </p>
          </div>
        </div>
      </div>
      
      {/* How to Play Section */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-white">
        <div className="max-w-7xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">How to Play</h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mx-auto mb-4">
                <span className="font-bold text-xl">1</span>
              </div>
              <h3 className="font-bold mb-2">Match Emojis</h3>
              <p className="text-gray-600">Swap adjacent emojis to create matches of 3 or more identical emojis</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mx-auto mb-4">
                <span className="font-bold text-xl">2</span>
              </div>
              <h3 className="font-bold mb-2">Score Points</h3>
              <p className="text-gray-600">Each match earns points, with longer matches earning bonus points</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mx-auto mb-4">
                <span className="font-bold text-xl">3</span>
              </div>
              <h3 className="font-bold mb-2">Connect Wallet</h3>
              <p className="text-gray-600">Connect your Ethereum-compatible wallet to enable NFT minting</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-purple-100 text-purple-600 flex items-center justify-center mx-auto mb-4">
                <span className="font-bold text-xl">4</span>
              </div>
              <h3 className="font-bold mb-2">Mint NFTs</h3>
              <p className="text-gray-600">Turn your game achievements into unique NFTs on the Fluent blockchain</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* CTA Section */}
      <div className="py-16 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-purple-600 to-pink-500 text-white">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Play?</h2>
          <p className="text-xl mb-8">Start matching emojis and earning NFTs today!</p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link to="/solo">
              <Button variant="accent" size="lg">
                Start Solo Game
              </Button>
            </Link>
            <Link to="/multiplayer">
              <Button variant="ghost" size="lg">
                Play with Friends
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;
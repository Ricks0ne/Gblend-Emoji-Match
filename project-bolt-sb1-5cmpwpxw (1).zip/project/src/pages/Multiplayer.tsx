import React, { useState, useEffect } from 'react';
import { useGame } from '../contexts/GameContext';
import EmojiGrid from '../components/game/EmojiGrid';
import ScoreBoard from '../components/game/ScoreBoard';
import Button from '../components/ui/Button';
import Modal from '../components/ui/Modal';
import NFTMint from '../components/wallet/NFTMint';
import WalletConnect from '../components/wallet/WalletConnect';
import { useWallet } from '../contexts/WalletContext';
import { NFT } from '../types';
import { Users, UserPlus, RotateCcw, HelpCircle } from 'lucide-react';

const Multiplayer: React.FC = () => {
  const { gameState, initGame, resetGame } = useGame();
  const { walletState } = useWallet();
  const [showMintModal, setShowMintModal] = useState(false);
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showHelpModal, setShowHelpModal] = useState(false);
  const [opponentName, setOpponentName] = useState('');
  const [opponentScore, setOpponentScore] = useState(0);
  const [waitingForOpponent, setWaitingForOpponent] = useState(false);
  const [roomCode, setRoomCode] = useState('');
  const [joinRoomCode, setJoinRoomCode] = useState('');
  const [mintedNFTs, setMintedNFTs] = useState<NFT[]>([]);

  // Create a game room
  const handleCreateRoom = () => {
    // Generate a random room code
    const newRoomCode = Math.random().toString(36).substring(2, 8).toUpperCase();
    setRoomCode(newRoomCode);
    setWaitingForOpponent(true);
    setShowCreateModal(false);
    
    // In a real implementation, this would create a room on a server
    // For this example, we'll simulate another player joining after a few seconds
    setTimeout(() => {
      setWaitingForOpponent(false);
      setOpponentName('Player 2');
      initGame('pvp');
    }, 3000);
  };

  // Join a game room
  const handleJoinRoom = () => {
    if (!joinRoomCode) {
      alert('Please enter a room code');
      return;
    }
    
    setShowJoinModal(false);
    
    // In a real implementation, this would join a room on a server
    // For this example, we'll simulate joining a room
    setOpponentName('Player 1');
    initGame('pvp');
  };

  // Initialize opponent's score simulation
  useEffect(() => {
    if (gameState.gameMode === 'pvp' && !gameState.isGameOver) {
      // Simulate opponent's score increasing
      const interval = setInterval(() => {
        setOpponentScore(prev => prev + Math.floor(Math.random() * 10));
      }, 5000);
      
      return () => clearInterval(interval);
    }
  }, [gameState.gameMode, gameState.isGameOver]);

  // Handle game completion
  useEffect(() => {
    if (gameState.isGameOver && gameState.score > 0) {
      setShowMintModal(true);
    }
  }, [gameState.isGameOver, gameState.score]);

  // Handle mint completion
  const handleMintComplete = (nft: NFT) => {
    setMintedNFTs([...mintedNFTs, nft]);
  };

  // Start a new game
  const handleNewGame = () => {
    resetGame();
    setOpponentName('');
    setOpponentScore(0);
    setRoomCode('');
  };

  // Show help modal
  const toggleHelpModal = () => {
    setShowHelpModal(!showHelpModal);
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-6 flex justify-between items-center">
        <h1 className="text-3xl font-bold text-pink-600">Multiplayer Game</h1>
        
        <div className="flex space-x-2">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleHelpModal}
            leftIcon={<HelpCircle size={16} />}
          >
            How to Play
          </Button>
          
          {opponentName ? (
            <Button
              variant="primary"
              size="sm"
              onClick={handleNewGame}
              leftIcon={<RotateCcw size={16} />}
            >
              New Game
            </Button>
          ) : (
            <>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => setShowCreateModal(true)}
                leftIcon={<UserPlus size={16} />}
              >
                Create Game
              </Button>
              <Button
                variant="primary"
                size="sm"
                onClick={() => setShowJoinModal(true)}
                leftIcon={<Users size={16} />}
              >
                Join Game
              </Button>
            </>
          )}
        </div>
      </div>
      
      {waitingForOpponent ? (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <div className="animate-spin w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full inline-block mb-4"></div>
          <h2 className="text-2xl font-bold mb-4">Waiting for opponent...</h2>
          <p className="mb-6">Share this room code with your friend:</p>
          <div className="bg-gray-100 p-4 rounded-lg text-2xl font-bold tracking-widest mb-6">
            {roomCode}
          </div>
          <Button variant="secondary" onClick={handleNewGame}>
            Cancel
          </Button>
        </div>
      ) : opponentName ? (
        <>
          {/* Game scoreoard */}
          <div className="mb-6">
            <ScoreBoard
              score={gameState.score}
              gameMode={gameState.gameMode}
              timeRemaining={gameState.time}
              level={gameState.level}
              categoryMastery={gameState.categoryMastery}
            />
          </div>
          
          {/* Opponent info */}
          <div className="mb-4 bg-white rounded-lg shadow-md p-4">
            <div className="flex justify-between items-center">
              <div>
                <span className="text-sm text-gray-500">Opponent:</span>
                <span className="ml-2 font-medium">{opponentName}</span>
              </div>
              <div>
                <span className="text-sm text-gray-500">Score:</span>
                <span className="ml-2 font-bold text-pink-600">{opponentScore}</span>
              </div>
            </div>
          </div>
          
          {/* Game grid */}
          <div className="mb-8">
            <EmojiGrid />
          </div>
          
          {/* Game footer */}
          <div className="mt-8">
            {gameState.isGameOver ? (
              <div className="text-center">
                <h2 className="text-2xl font-bold mb-4">
                  {gameState.score > opponentScore ? 'You Win! 🎉' : gameState.score < opponentScore ? 'You Lost! 😢' : 'It\'s a Tie! 🤝'}
                </h2>
                <p className="text-lg mb-6">
                  Your score: <span className="font-bold text-purple-600">{gameState.score}</span> |
                  Opponent score: <span className="font-bold text-pink-600">{opponentScore}</span>
                </p>
                
                <div className="flex justify-center gap-4">
                  <Button
                    variant="primary"
                    onClick={() => setShowMintModal(true)}
                    disabled={!walletState.isConnected}
                  >
                    Mint NFT
                  </Button>
                  
                  <Button
                    variant="secondary"
                    onClick={handleNewGame}
                  >
                    Play Again
                  </Button>
                </div>
                
                {!walletState.isConnected && (
                  <div className="mt-4 text-sm text-gray-600">
                    Connect your wallet to mint an NFT for this achievement!
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-white p-4 rounded-lg shadow-md">
                <h3 className="font-medium mb-2">Multiplayer Tips:</h3>
                <ul className="text-sm text-gray-600 list-disc list-inside">
                  <li>Score more points than your opponent to win</li>
                  <li>Focus on making longer matches for more points</li>
                  <li>Keep an eye on your opponent's score</li>
                  <li>Win or lose, you can still mint an NFT of your achievement</li>
                </ul>
              </div>
            )}
          </div>
        </>
      ) : (
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <div className="mb-8">
            <Users size={64} className="mx-auto mb-4 text-pink-500" />
            <h2 className="text-2xl font-bold mb-2">Play with Friends</h2>
            <p className="text-gray-600">Create a new game or join an existing one to play against a friend!</p>
          </div>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button
              variant="secondary"
              size="lg"
              onClick={() => setShowCreateModal(true)}
              leftIcon={<UserPlus size={20} />}
            >
              Create Game
            </Button>
            <Button
              variant="primary"
              size="lg"
              onClick={() => setShowJoinModal(true)}
              leftIcon={<Users size={20} />}
            >
              Join Game
            </Button>
          </div>
        </div>
      )}
      
      {/* Create Game Modal */}
      <Modal
        isOpen={showCreateModal}
        onClose={() => setShowCreateModal(false)}
        title="Create Multiplayer Game"
      >
        <div className="space-y-6">
          <p className="text-gray-600">
            Create a new game room and share the code with a friend to play together.
          </p>
          
          <div className="flex justify-center">
            <Button
              variant="primary"
              onClick={handleCreateRoom}
              size="lg"
              className="w-full"
            >
              Create Game Room
            </Button>
          </div>
        </div>
      </Modal>
      
      {/* Join Game Modal */}
      <Modal
        isOpen={showJoinModal}
        onClose={() => setShowJoinModal(false)}
        title="Join Multiplayer Game"
      >
        <div className="space-y-6">
          <p className="text-gray-600">
            Enter the room code shared by your friend to join their game.
          </p>
          
          <div>
            <label htmlFor="roomCode" className="block text-sm font-medium text-gray-700 mb-1">
              Room Code
            </label>
            <input
              type="text"
              id="roomCode"
              value={joinRoomCode}
              onChange={(e) => setJoinRoomCode(e.target.value.toUpperCase())}
              placeholder="Enter 6-digit code"
              className="w-full p-3 border border-gray-300 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500"
              maxLength={6}
            />
          </div>
          
          <Button
            variant="primary"
            onClick={handleJoinRoom}
            size="lg"
            className="w-full"
            disabled={!joinRoomCode}
          >
            Join Game
          </Button>
        </div>
      </Modal>
      
      {/* NFT Mint Modal */}
      <Modal
        isOpen={showMintModal}
        onClose={() => setShowMintModal(false)}
        title="Mint Your Achievement NFT"
      >
        {!walletState.isConnected ? (
          <WalletConnect onConnect={() => {}} />
        ) : (
          <NFTMint
            score={gameState.score}
            gameMode={gameState.gameMode}
            categoryMastery={gameState.categoryMastery}
            onMintComplete={handleMintComplete}
          />
        )}
      </Modal>
      
      {/* Help Modal */}
      <Modal
        isOpen={showHelpModal}
        onClose={() => setShowHelpModal(false)}
        title="How to Play Multiplayer"
      >
        <div className="space-y-4">
          <div>
            <h3 className="font-bold mb-2">Multiplayer Rules:</h3>
            <ul className="list-disc list-inside text-gray-700">
              <li>Create a game room or join an existing one with a 6-digit code</li>
              <li>Match 3 or more identical emojis to score points</li>
              <li>The player with the highest score when the timer ends wins</li>
              <li>Both players can mint NFTs regardless of who wins</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold mb-2">Creating a Game:</h3>
            <ul className="list-disc list-inside text-gray-700">
              <li>Click "Create Game" to generate a room code</li>
              <li>Share the 6-digit code with your friend</li>
              <li>Wait for your opponent to join</li>
            </ul>
          </div>
          
          <div>
            <h3 className="font-bold mb-2">Joining a Game:</h3>
            <ul className="list-disc list-inside text-gray-700">
              <li>Click "Join Game" to open the join dialog</li>
              <li>Enter the 6-digit room code shared by your friend</li>
              <li>Click "Join Game" to enter the match</li>
            </ul>
          </div>
          
          <div className="pt-4">
            <Button variant="primary" onClick={toggleHelpModal} className="w-full">
              Got it!
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default Multiplayer;
import React from 'react';
import { Clock, Award, Target } from 'lucide-react';
import { EmojiCategory, GameMode } from '../../types';
import { getMasteryTitle } from '../../utils/emojiUtils';

interface ScoreBoardProps {
  score: number;
  gameMode: GameMode;
  timeRemaining: number;
  level: number;
  categoryMastery: Record<EmojiCategory, number>;
}

const ScoreBoard: React.FC<ScoreBoardProps> = ({
  score,
  gameMode,
  timeRemaining,
  level,
  categoryMastery
}) => {
  // Find the emoji category with the highest mastery score
  const topCategory = Object.entries(categoryMastery).reduce(
    (prev, [category, score]) => (score > prev.score ? { category: category as EmojiCategory, score } : prev),
    { category: EmojiCategory.FOOD, score: -1 }
  );
  
  // Format time remaining
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-4 flex flex-col md:flex-row md:justify-between items-center">
      <div className="flex items-center mb-4 md:mb-0">
        <div className="mr-8 text-center">
          <h3 className="text-sm font-medium text-gray-500">SCORE</h3>
          <p className="text-3xl font-bold text-purple-600">{score}</p>
        </div>
        
        <div className="flex items-center bg-gradient-to-r from-purple-500 to-pink-500 text-white py-2 px-4 rounded-full">
          <Clock size={18} className="mr-2" />
          <span className="font-medium">{formatTime(timeRemaining)}</span>
        </div>
      </div>
      
      <div className="flex flex-col sm:flex-row items-center gap-4">
        <div className="text-center px-4 py-2 bg-gray-100 rounded-md">
          <div className="text-xs uppercase text-gray-500 mb-1">Mode</div>
          <div className="font-medium">
            {gameMode === 'solo' ? 'Solo Play' : 'Multiplayer PvP'}
          </div>
        </div>
        
        <div className="text-center px-4 py-2 bg-gray-100 rounded-md">
          <div className="text-xs uppercase text-gray-500 mb-1">Level</div>
          <div className="font-medium flex items-center justify-center">
            <Target size={16} className="mr-1 text-purple-600" />
            <span>{level}</span>
          </div>
        </div>
        
        <div className="text-center px-4 py-2 bg-gray-100 rounded-md">
          <div className="text-xs uppercase text-gray-500 mb-1">Mastery</div>
          <div className="font-medium flex items-center justify-center">
            <Award size={16} className="mr-1 text-yellow-500" />
            <span title={`Score: ${topCategory.score}`}>{getMasteryTitle(topCategory.category)}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScoreBoard;
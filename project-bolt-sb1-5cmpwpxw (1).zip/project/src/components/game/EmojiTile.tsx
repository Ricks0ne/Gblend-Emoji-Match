import React from 'react';
import { EmojiType } from '../../types';

interface EmojiTileProps {
  emoji: EmojiType;
  isSelected: boolean;
  isMatched: boolean;
  onClick: () => void;
  row: number;
  col: number;
}

const EmojiTile: React.FC<EmojiTileProps> = ({
  emoji,
  isSelected,
  isMatched,
  onClick,
  row,
  col
}) => {
  // Base classes
  const baseClasses = 'flex items-center justify-center text-3xl sm:text-4xl md:text-5xl cursor-pointer select-none transition-all duration-200 ease-in-out';
  
  // Apply different styles based on state
  const styleClasses = isMatched
    ? 'opacity-50 scale-75' // Matched state
    : isSelected
      ? 'bg-purple-200 scale-110 shadow-lg ring-2 ring-purple-500' // Selected state
      : 'hover:bg-gray-100 hover:scale-105'; // Default state
  
  // Animation delay based on position to create cascade effect
  const animationDelay = `${(row + col) * 0.05}s`;
  
  return (
    <div
      className={`${baseClasses} ${styleClasses}`}
      onClick={onClick}
      style={{
        animationDelay,
        transitionDelay: animationDelay,
        aspectRatio: '1/1'
      }}
    >
      <span>{emoji.symbol}</span>
    </div>
  );
};

export default EmojiTile;
import React, { useState, useEffect } from 'react';
import { EmojiType, GridPosition } from '../../types';
import { useGame } from '../../contexts/GameContext';
import EmojiTile from './EmojiTile';

interface EmojiGridProps {
  onMatchFound?: (score: number) => void;
}

const EmojiGrid: React.FC<EmojiGridProps> = ({ onMatchFound }) => {
  const { gameState, swapEmojis, processMatches } = useGame();
  const [selectedPosition, setSelectedPosition] = useState<GridPosition | null>(null);
  const [matchedPositions, setMatchedPositions] = useState<GridPosition[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  // Handle tile click
  const handleTileClick = async (row: number, col: number) => {
    if (isProcessing || gameState.isGameOver) return;
    
    const clickedPosition: GridPosition = { row, col };
    
    // If no tile is selected, select this one
    if (!selectedPosition) {
      setSelectedPosition(clickedPosition);
      return;
    }
    
    // If the same tile is clicked again, deselect it
    if (selectedPosition.row === row && selectedPosition.col === col) {
      setSelectedPosition(null);
      return;
    }
    
    // Try to swap tiles
    setIsProcessing(true);
    const swapSuccess = await swapEmojis(selectedPosition, clickedPosition);
    
    if (swapSuccess) {
      // If swap was successful, find matches
      const score = await processMatches();
      
      if (onMatchFound) {
        onMatchFound(score);
      }
    }
    
    // Reset selection
    setSelectedPosition(null);
    setIsProcessing(false);
  };

  // Check if a position is in the matched positions array
  const isPositionMatched = (row: number, col: number): boolean => {
    return matchedPositions.some(pos => pos.row === row && pos.col === col);
  };

  // Update matched positions effect
  useEffect(() => {
    const checkMatches = async () => {
      if (gameState.grid.length === 0) return;
      
      // Import findMatches here to avoid circular dependency
      const { findMatches } = await import('../../utils/emojiUtils');
      const matches = findMatches(gameState.grid);
      
      if (matches.length > 0) {
        const flatMatches = matches.flat();
        setMatchedPositions(flatMatches);
        
        // Clear matched positions after animation
        setTimeout(() => {
          setMatchedPositions([]);
        }, 500);
      }
    };
    
    checkMatches();
  }, [gameState.grid]);

  // If grid is empty, don't render
  if (!gameState.grid.length) return null;

  return (
    <div className="relative">
      <div 
        className={`grid gap-1 sm:gap-2 rounded-lg p-2 bg-white shadow-lg transition-opacity duration-300 ${
          gameState.isGameOver ? 'opacity-50 pointer-events-none' : 'opacity-100'
        }`}
        style={{ 
          gridTemplateColumns: `repeat(${gameState.grid[0].length}, 1fr)`,
          gridTemplateRows: `repeat(${gameState.grid.length}, 1fr)`
        }}
      >
        {gameState.grid.map((row, rowIndex) => 
          row.map((emoji: EmojiType, colIndex: number) => (
            <EmojiTile
              key={`${rowIndex}-${colIndex}-${emoji.id}`}
              emoji={emoji}
              isSelected={selectedPosition?.row === rowIndex && selectedPosition?.col === colIndex}
              isMatched={isPositionMatched(rowIndex, colIndex)}
              onClick={() => handleTileClick(rowIndex, colIndex)}
              row={rowIndex}
              col={colIndex}
            />
          ))
        )}
      </div>
      
      {gameState.isGameOver && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg">
          <div className="text-white text-xl font-bold">Game Over!</div>
        </div>
      )}
    </div>
  );
};

export default EmojiGrid;
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Gamepad2, Trophy, User, Wallet, Menu, X } from 'lucide-react';
import { useWallet } from '../../contexts/WalletContext';
import { formatWalletAddress } from '../../utils/nftUtils';
import Button from './Button';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();
  const { walletState, connectToWallet, disconnectWallet } = useWallet();

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const closeMenu = () => {
    setIsMenuOpen(false);
  };

  const handleWalletConnect = async () => {
    if (walletState.isConnected) {
      disconnectWallet();
    } else {
      await connectToWallet();
    }
  };

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <nav className="bg-gradient-to-r from-purple-800 to-pink-700 text-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center">
              <Gamepad2 className="mr-2" size={24} />
              <span className="font-bold text-xl">Emoji Match Arena</span>
            </div>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex md:items-center md:space-x-4">
            <Link
              to="/"
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                isActive('/') 
                  ? 'bg-purple-900 text-white' 
                  : 'text-white hover:bg-purple-700'
              }`}
            >
              Home
            </Link>
            <Link
              to="/solo"
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                isActive('/solo') 
                  ? 'bg-purple-900 text-white' 
                  : 'text-white hover:bg-purple-700'
              }`}
            >
              Solo Game
            </Link>
            <Link
              to="/multiplayer"
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                isActive('/multiplayer') 
                  ? 'bg-purple-900 text-white' 
                  : 'text-white hover:bg-purple-700'
              }`}
            >
              Multiplayer
            </Link>
            <Link
              to="/leaderboard"
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                isActive('/leaderboard') 
                  ? 'bg-purple-900 text-white' 
                  : 'text-white hover:bg-purple-700'
              }`}
            >
              <div className="flex items-center">
                <Trophy size={16} className="mr-1" />
                Leaderboard
              </div>
            </Link>
            <Link
              to="/profile"
              className={`px-3 py-2 rounded-md text-sm font-medium ${
                isActive('/profile') 
                  ? 'bg-purple-900 text-white' 
                  : 'text-white hover:bg-purple-700'
              }`}
            >
              <div className="flex items-center">
                <User size={16} className="mr-1" />
                Profile
              </div>
            </Link>
          </div>
          
          <div className="hidden md:flex md:items-center">
            <Button
              variant={walletState.isConnected ? 'accent' : 'primary'}
              size="sm"
              onClick={handleWalletConnect}
              leftIcon={<Wallet size={16} />}
            >
              {walletState.isConnected 
                ? formatWalletAddress(walletState.address) 
                : 'Connect Wallet'}
            </Button>
          </div>
          
          {/* Mobile menu button */}
          <div className="flex md:hidden items-center">
            <button
              onClick={toggleMenu}
              className="text-white hover:text-gray-200 focus:outline-none"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMenuOpen && (
        <div className="md:hidden bg-purple-900">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            <Link
              to="/"
              className={`block px-3 py-2 rounded-md text-base font-medium ${
                isActive('/') 
                  ? 'bg-purple-800 text-white' 
                  : 'text-white hover:bg-purple-700'
              }`}
              onClick={closeMenu}
            >
              Home
            </Link>
            <Link
              to="/solo"
              className={`block px-3 py-2 rounded-md text-base font-medium ${
                isActive('/solo') 
                  ? 'bg-purple-800 text-white' 
                  : 'text-white hover:bg-purple-700'
              }`}
              onClick={closeMenu}
            >
              Solo Game
            </Link>
            <Link
              to="/multiplayer"
              className={`block px-3 py-2 rounded-md text-base font-medium ${
                isActive('/multiplayer') 
                  ? 'bg-purple-800 text-white' 
                  : 'text-white hover:bg-purple-700'
              }`}
              onClick={closeMenu}
            >
              Multiplayer
            </Link>
            <Link
              to="/leaderboard"
              className={`block px-3 py-2 rounded-md text-base font-medium ${
                isActive('/leaderboard') 
                  ? 'bg-purple-800 text-white' 
                  : 'text-white hover:bg-purple-700'
              }`}
              onClick={closeMenu}
            >
              <div className="flex items-center">
                <Trophy size={16} className="mr-1" />
                Leaderboard
              </div>
            </Link>
            <Link
              to="/profile"
              className={`block px-3 py-2 rounded-md text-base font-medium ${
                isActive('/profile') 
                  ? 'bg-purple-800 text-white' 
                  : 'text-white hover:bg-purple-700'
              }`}
              onClick={closeMenu}
            >
              <div className="flex items-center">
                <User size={16} className="mr-1" />
                Profile
              </div>
            </Link>
            
            <Button
              variant={walletState.isConnected ? 'accent' : 'primary'}
              size="sm"
              onClick={() => {
                handleWalletConnect();
                closeMenu();
              }}
              leftIcon={<Wallet size={16} />}
              className="w-full mt-4"
            >
              {walletState.isConnected 
                ? formatWalletAddress(walletState.address) 
                : 'Connect Wallet'}
            </Button>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
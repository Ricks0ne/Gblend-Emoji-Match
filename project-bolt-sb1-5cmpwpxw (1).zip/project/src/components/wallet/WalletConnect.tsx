import React, { useState, useEffect } from 'react';
import { useWallet } from '../../contexts/WalletContext';
import { Wallet, AlertTriangle, CheckCircle, ExternalLink } from 'lucide-react';
import Button from '../ui/Button';
import { formatWalletAddress } from '../../utils/nftUtils';

interface WalletConnectProps {
  onConnect?: () => void;
}

const WalletConnect: React.FC<WalletConnectProps> = ({ onConnect }) => {
  const { walletState, connectToWallet, switchToCorrectChain } = useWallet();
  const [isConnecting, setIsConnecting] = useState(false);
  const [hasWallet, setHasWallet] = useState(false);

  useEffect(() => {
    setHasWallet(!!window.ethereum);
  }, []);

  // Handle wallet connection
  const handleConnect = async () => {
    if (!hasWallet) return;
    
    setIsConnecting(true);
    
    try {
      await connectToWallet();
      
      if (onConnect) {
        onConnect();
      }
    } catch (error) {
      console.error("Failed to connect wallet:", error);
    } finally {
      setIsConnecting(false);
    }
  };

  // Handle switching to correct chain
  const handleSwitchChain = async () => {
    setIsConnecting(true);
    
    try {
      await switchToCorrectChain();
    } catch (error) {
      console.error("Failed to switch chain:", error);
    } finally {
      setIsConnecting(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6 max-w-md mx-auto">
      <div className="text-center mb-6">
        <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-purple-100 text-purple-600 mb-4">
          <Wallet size={24} />
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Wallet Connection</h2>
        <p className="text-gray-600">
          Connect your wallet to mint NFTs based on your gameplay achievements.
        </p>
      </div>
      
      {!hasWallet && (
        <div className="p-4 bg-yellow-50 rounded-lg mb-4">
          <div className="flex items-start">
            <AlertTriangle className="text-yellow-500 mr-2 flex-shrink-0 mt-1" size={20} />
            <div>
              <p className="text-sm text-yellow-700 mb-2">
                No Ethereum wallet detected. Please install MetaMask or another compatible wallet to continue.
              </p>
              <a
                href="https://metamask.io/download/"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-sm text-purple-600 hover:text-purple-700 font-medium"
              >
                Install MetaMask
                <ExternalLink size={14} className="ml-1" />
              </a>
            </div>
          </div>
        </div>
      )}
      
      {walletState.isConnected ? (
        <div className="space-y-4">
          <div className="p-4 bg-gray-50 rounded-lg flex items-center justify-between">
            <div>
              <div className="text-sm text-gray-500">Connected Wallet</div>
              <div className="font-medium">{formatWalletAddress(walletState.address)}</div>
            </div>
            <CheckCircle className="text-green-500" size={20} />
          </div>
          
          {!walletState.isCorrectChain && (
            <div className="p-4 bg-yellow-50 rounded-lg flex items-center">
              <AlertTriangle className="text-yellow-500 mr-2 flex-shrink-0" size={20} />
              <div className="text-sm text-yellow-700">
                You need to switch to the Fluent blockchain network (Chain ID: 20993) to mint NFTs.
              </div>
            </div>
          )}
          
          {!walletState.isCorrectChain && (
            <Button
              variant="primary"
              className="w-full"
              onClick={handleSwitchChain}
              isLoading={isConnecting}
            >
              Switch to Fluent Network
            </Button>
          )}
        </div>
      ) : (
        <Button
          variant="primary"
          className="w-full"
          onClick={handleConnect}
          isLoading={isConnecting}
          disabled={!hasWallet}
          leftIcon={<Wallet size={16} />}
        >
          {hasWallet ? 'Connect Wallet' : 'Wallet Not Detected'}
        </Button>
      )}
      
      <div className="mt-4 text-xs text-gray-500 text-center">
        We support MetaMask and other Ethereum-compatible wallets.
      </div>
    </div>
  );
};

export default WalletConnect;
import React, { useState } from 'react';
import { useWallet } from '../../contexts/WalletContext';
import Button from '../ui/Button';
import { EmojiCategory, GameMode, NFT } from '../../types';
import { generateNFTMetadata } from '../../utils/nftUtils';
import { mockMintNFT } from '../../services/blockchain';
import { determineEmojiMastery } from '../../utils/emojiUtils';
import { Award, Gift } from 'lucide-react';

interface NFTMintProps {
  score: number;
  gameMode: GameMode;
  categoryMastery: Record<EmojiCategory, number>;
  onMintComplete?: (nft: NFT) => void;
}

const NFTMint: React.FC<NFTMintProps> = ({
  score,
  gameMode,
  categoryMastery,
  onMintComplete
}) => {
  const { walletState } = useWallet();
  const [isMinting, setIsMinting] = useState(false);
  const [isSoulbound, setIsSoulbound] = useState(false);
  const [mintedNFT, setMintedNFT] = useState<NFT | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Determine top emoji category mastery
  const topEmojiCategory = determineEmojiMastery(categoryMastery);

  // Handle NFT minting
  const handleMint = async () => {
    if (!walletState.isConnected || !walletState.address) {
      setError("Please connect your wallet first.");
      return;
    }
    
    if (!walletState.isCorrectChain) {
      setError("Please switch to the Fluent blockchain network.");
      return;
    }
    
    setIsMinting(true);
    setError(null);
    
    try {
      // Generate metadata
      const metadata = generateNFTMetadata(score, gameMode, topEmojiCategory, isSoulbound);
      
      // Mint NFT
      const tokenId = await mockMintNFT(walletState.address, metadata);
      
      // Create NFT object
      const nft: NFT = {
        id: `nft-${Date.now()}`,
        tokenId,
        score,
        gameMode,
        seasonBadge: metadata.attributes.find(a => a.trait_type === "Season Badge")?.value as string || "S1: Emoji Blitz",
        emojiMastery: topEmojiCategory,
        timestamp: Date.now(),
        isSoulbound,
        imageUrl: metadata.image
      };
      
      // Set minted NFT
      setMintedNFT(nft);
      
      // Call onMintComplete callback
      if (onMintComplete) {
        onMintComplete(nft);
      }
    } catch (error: any) {
      console.error("Error minting NFT:", error);
      setError(error.message || "Failed to mint NFT. Please try again.");
    } finally {
      setIsMinting(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      {!mintedNFT ? (
        <>
          <div className="text-center mb-6">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-purple-100 text-purple-600 mb-4">
              <Award size={24} />
            </div>
            <h2 className="text-2xl font-bold text-gray-800 mb-2">Mint Your Achievement NFT</h2>
            <p className="text-gray-600">
              Turn your game score into a unique NFT on the Fluent blockchain!
            </p>
          </div>
          
          <div className="space-y-4 mb-6">
            <div className="p-4 bg-gray-50 rounded-lg">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-sm text-gray-500">Score</div>
                  <div className="font-bold text-xl text-purple-600">{score}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Game Mode</div>
                  <div className="font-medium">{gameMode === 'solo' ? 'Solo Play' : 'PvP'}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Season</div>
                  <div className="font-medium">S1: Emoji Blitz</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500">Emoji Mastery</div>
                  <div className="font-medium">{topEmojiCategory}</div>
                </div>
              </div>
            </div>
            
            <div className="flex items-center">
              <input
                type="checkbox"
                id="soulbound"
                checked={isSoulbound}
                onChange={() => setIsSoulbound(!isSoulbound)}
                className="h-4 w-4 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
              />
              <label htmlFor="soulbound" className="ml-2 block text-sm text-gray-700">
                Make this a Soulbound Token (non-transferable)
              </label>
            </div>
          </div>
          
          {error && (
            <div className="mb-4 p-3 bg-red-50 text-red-700 rounded-md text-sm">
              {error}
            </div>
          )}
          
          <Button
            variant="primary"
            className="w-full"
            onClick={handleMint}
            isLoading={isMinting}
            disabled={!walletState.isConnected || !walletState.isCorrectChain || isMinting}
          >
            {isMinting ? 'Confirm the transaction in your wallet...' : 'Mint NFT'}
          </Button>
          
          {!walletState.isConnected && (
            <div className="mt-4 text-sm text-red-500 text-center">
              Please connect your wallet first.
            </div>
          )}
          
          {walletState.isConnected && !walletState.isCorrectChain && (
            <div className="mt-4 text-sm text-yellow-500 text-center">
              Please switch to the Fluent blockchain network.
            </div>
          )}
        </>
      ) : (
        <div className="text-center">
          <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-green-100 text-green-600 mb-4">
            <Gift size={24} />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">NFT Successfully Minted!</h2>
          
          <div className="mt-6 bg-gray-50 p-4 rounded-lg">
            <img 
              src={mintedNFT.imageUrl} 
              alt="NFT" 
              className="w-full h-64 object-cover rounded-lg mb-4" 
            />
            
            <div className="text-left">
              <div className="mb-2">
                <span className="text-sm text-gray-500">Token ID:</span>
                <span className="ml-2 font-medium">{mintedNFT.tokenId}</span>
              </div>
              <div className="mb-2">
                <span className="text-sm text-gray-500">Season Badge:</span>
                <span className="ml-2 font-medium">{mintedNFT.seasonBadge}</span>
              </div>
              <div className="mb-2">
                <span className="text-sm text-gray-500">Emoji Mastery:</span>
                <span className="ml-2 font-medium">{mintedNFT.emojiMastery}</span>
              </div>
              <div>
                <span className="text-sm text-gray-500">Type:</span>
                <span className="ml-2 font-medium">
                  {mintedNFT.isSoulbound ? 'Soulbound Token (Non-transferable)' : 'Transferable NFT'}
                </span>
              </div>
            </div>
          </div>
          
          <div className="mt-6">
            <Button
              variant="secondary"
              onClick={() => setMintedNFT(null)}
            >
              Mint Another NFT
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default NFTMint;